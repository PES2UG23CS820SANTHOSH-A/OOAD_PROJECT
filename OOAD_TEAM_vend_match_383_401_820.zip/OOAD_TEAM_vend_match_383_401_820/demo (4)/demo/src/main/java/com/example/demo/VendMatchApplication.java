package com.example.demo;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.*;

import java.util.*;

@SpringBootApplication
@RestController
public class VendMatchApplication implements CommandLineRunner {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public static void main(String[] args) {
        SpringApplication.run(VendMatchApplication.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println("\u2705 VendMatch Application Started!");
        createDefaultAdmin();
    }

    private void createDefaultAdmin() {
        try {
            String check = "SELECT COUNT(*) FROM users WHERE username = ?";
            Integer count = jdbcTemplate.queryForObject(check, Integer.class, "sam");
            if (count == 0) {
                jdbcTemplate.update("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)",
                        "SAM1", "sam", "1718", "ADMIN");
                System.out.println("\u2705 Default admin created: sam / 1718");
            }
        } catch (Exception e) {
            System.err.println("\u274C Admin creation error: " + e.getMessage());
        }
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedOrigins("*").allowedMethods("*");
            }
        };
    }

    static class User {
        private String username, password, role;
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
    }

    static class ProcurementRequest {
        private String title, items, itemsQuantity, buyerId;
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getItems() { return items; }
        public void setItems(String items) { this.items = items; }
        public String getItemsQuantity() { return itemsQuantity; }
        public void setItemsQuantity(String itemsQuantity) { this.itemsQuantity = itemsQuantity; }
        public String getBuyerId() { return buyerId; }
        public void setBuyerId(String buyerId) { this.buyerId = buyerId; }
    }

    static class Bid {
        private double amount;
        private String supplierId, requestId;
        public double getAmount() { return amount; }
        public void setAmount(double amount) { this.amount = amount; }
        public String getSupplierId() { return supplierId; }
        public void setSupplierId(String supplierId) { this.supplierId = supplierId; }
        public String getRequestId() { return requestId; }
        public void setRequestId(String requestId) { this.requestId = requestId; }
    }

    static class LoginResponse {
        public String status;
        public String message;
        public String role;
        public String userId;
        public List<Map<String, Object>> data = new ArrayList<>();

        public LoginResponse(String status, String message, String role, String userId) {
            this.status = status;
            this.message = message;
            this.role = role;
            this.userId = userId;
        }
    }

    @PostMapping("/register")
    public Map<String, String> register(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();
        try {
            String role = user.getRole().toUpperCase();
            if ("ADMIN".equals(role)) {
                response.put("status", "error");
                response.put("message", "Admin registration not allowed.");
                return response;
            }
            String prefix = role.equals("BUYER") ? "BUY" : "SUP";
            int count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users WHERE role = ?", Integer.class, role);
            String userId = prefix + String.format("%03d", count + 1);
            jdbcTemplate.update("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)", userId, user.getUsername(), user.getPassword(), role);
            response.put("status", "success");
            response.put("userId", userId);
            response.put("role", role);
            return response;
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
            return response;
        }
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody User user) {
        try {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
            List<Map<String, Object>> res = jdbcTemplate.queryForList(sql, user.getUsername(), user.getPassword(), user.getRole());
            if (res.isEmpty()) return new LoginResponse("error", "Invalid credentials.", null, null);

            String userId = (String) res.get(0).get("user_id");
            String role = user.getRole().toUpperCase();
            LoginResponse response = new LoginResponse("success", "Login successful", role, userId);

            if ("SUPPLIER".equals(role)) {
                response.data = jdbcTemplate.queryForList("SELECT request_id, title FROM procurement_requests WHERE status = 'Open'");
            } else if ("ADMIN".equals(role)) {
                response.data = jdbcTemplate.queryForList("SELECT request_id, title, status FROM procurement_requests");
            } else if ("BUYER".equals(role)) {
                response.data = jdbcTemplate.queryForList("SELECT request_id, title, status FROM procurement_requests WHERE buyer_id = ?", userId);
            }
            return response;
        } catch (Exception e) {
            return new LoginResponse("error", "Login error: " + e.getMessage(), null, null);
        }
    }

    @PostMapping("/procurement")
    public String createProcurement(@RequestBody ProcurementRequest req) {
        try {
            String checkSql = "SELECT COUNT(*) FROM users WHERE user_id = ? AND role = 'BUYER'";
            int valid = jdbcTemplate.queryForObject(checkSql, Integer.class, req.getBuyerId());
            if (valid == 0) return "\u274C Invalid buyer ID.";
            int count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM procurement_requests", Integer.class);
            String requestId = "reqs" + String.format("%03d", count + 1);
            jdbcTemplate.update("INSERT INTO procurement_requests (request_id, title, items, items_quantity, buyer_id, status) VALUES (?, ?, ?, ?, ?, 'Pending')",
                    requestId, req.getTitle(), req.getItems(), req.getItemsQuantity(), req.getBuyerId());
            return "\u2705 Request created: " + requestId;
        } catch (Exception e) {
            return "\u274C Error creating request: " + e.getMessage();
        }
    }

    @PostMapping("/bid")
    public String placeBid(@RequestBody Bid bid) {
        try {
            String status = jdbcTemplate.queryForObject("SELECT status FROM procurement_requests WHERE request_id = ?", String.class, bid.getRequestId());
            if (!"Open".equalsIgnoreCase(status)) return "\u274C Bidding not open.";
            String bidId = "supbd" + System.currentTimeMillis();
            jdbcTemplate.update("INSERT INTO bids (bid_id, request_id, supplier_id, amount, admin_approval) VALUES (?, ?, ?, ?, 'Pending')",
                    bidId, bid.getRequestId(), bid.getSupplierId(), bid.getAmount());
            return "\u2705 Bid placed: " + bidId;
        } catch (Exception e) {
            return "\u274C Bid error: " + e.getMessage();
        }
    }

    @PostMapping("/admin/requests/open/{requestId}")
    public String openBid(@PathVariable String requestId) {
        int rows = jdbcTemplate.update("UPDATE procurement_requests SET status = 'Open' WHERE request_id = ?", requestId);
        return rows > 0 ? "\u2705 Bidding opened for: " + requestId : "\u274C Request not found.";
    }

    @PostMapping("/approve/admin/{bidId}")
    public String adminApprove(@PathVariable String bidId) {
        int rows = jdbcTemplate.update("UPDATE bids SET admin_approval = 'Yes' WHERE bid_id = ?", bidId);
        if (rows > 0) {
            checkAndCreateResultAndOrder(bidId);
            return "\u2705 Admin approved: " + bidId;
        }
        return "\u274C Bid not found.";
    }

    private void checkAndCreateResultAndOrder(String bidId) {
        try {
            Map<String, Object> bid = jdbcTemplate.queryForMap("SELECT * FROM bids WHERE bid_id = ?", bidId);
            if ("Yes".equals(bid.get("admin_approval"))) {
                String requestId = (String) bid.get("request_id");
                Double amount = (Double) bid.get("amount");
                String supplierId = (String) bid.get("supplier_id");
                String buyerId = jdbcTemplate.queryForObject("SELECT buyer_id FROM procurement_requests WHERE request_id = ?", String.class, requestId);

                // Insert winning bid into results table
                jdbcTemplate.update("INSERT INTO results (request_id, supplier_id, amount) VALUES (?, ?, ?)", requestId, supplierId, amount);
                // Create order
                String orderId = "order" + System.currentTimeMillis();
                jdbcTemplate.update("INSERT INTO orders (order_id, request_id, supplier_id, buyer_id) VALUES (?, ?, ?, ?)",
                        orderId, requestId, supplierId, buyerId);
            }
        } catch (Exception e) {
            System.err.println("\u274C Error creating result or order: " + e.getMessage());
        }
    }

    // Admin Endpoints
    @GetMapping("/admin/requests")
    public List<Map<String, Object>> getAdminRequests() {
        return jdbcTemplate.queryForList("SELECT * FROM procurement_requests");
    }

    @GetMapping("/admin/bids/{requestId}")
    public List<Map<String, Object>> getAdminBids(@PathVariable String requestId) {
        return jdbcTemplate.queryForList("SELECT * FROM bids WHERE request_id = ? ORDER BY amount ASC", requestId);
    }

    @GetMapping("/admin/results")
    public List<Map<String, Object>> getAdminResults() {
        return jdbcTemplate.queryForList("SELECT * FROM results");
    }

    @GetMapping("/admin/orders")
    public List<Map<String, Object>> getAdminOrders() {
        return jdbcTemplate.queryForList("SELECT * FROM orders");
    }

    // Buyer Endpoints
    @GetMapping("/buyer/requests")
    public List<Map<String, Object>> getBuyerRequests(@RequestParam String buyerId) {
        return jdbcTemplate.queryForList("SELECT * FROM procurement_requests WHERE buyer_id = ?", buyerId);
    }

    @GetMapping("/buyer/orders")
    public List<Map<String, Object>> getBuyerOrders(@RequestParam String buyerId) {
        return jdbcTemplate.queryForList("SELECT * FROM orders WHERE buyer_id = ?", buyerId);
    }

    // Supplier Endpoints
    @GetMapping("/supplier/requests")
    public List<Map<String, Object>> getSupplierRequests() {
        return jdbcTemplate.queryForList("SELECT * FROM procurement_requests WHERE status = 'Open'");
    }

    @GetMapping("/supplier/orders")
    public List<Map<String, Object>> getSupplierOrders(@RequestParam String supplierId) {
        return jdbcTemplate.queryForList("SELECT * FROM orders WHERE supplier_id = ?", supplierId);
    }

    @GetMapping("/supplier/results")
    public List<Map<String, Object>> getSupplierResults(@RequestParam String supplierId) {
        return jdbcTemplate.queryForList("SELECT * FROM results WHERE supplier_id = ?", supplierId);
    }
}
