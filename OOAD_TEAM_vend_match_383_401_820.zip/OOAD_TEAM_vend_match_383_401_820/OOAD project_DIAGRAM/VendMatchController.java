package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import static com.example.demo.Models.*;

@RestController
public class VendMatchController {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private VendMatchService service;

    @PostMapping("/register")
    public Map<String, String> register(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();
        try {
            String role = user.getRole().toUpperCase();
            if ("ADMIN".equals(role)) {
                response.put("status", "error");
                response.put("message", "Admin registration not allowed.");
                return response;
            }
            String prefix = role.equals("BUYER") ? "BUY" : "SUP";
            int count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users WHERE role = ?", Integer.class, role);
            String userId = prefix + String.format("%03d", count + 1);
            jdbcTemplate.update("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)",
                    userId, user.getUsername(), user.getPassword(), role);
            response.put("status", "success");
            response.put("userId", userId);
            response.put("role", role);
        } catch (Exception e) {
            response.put("status", "error");
            response.put("message", e.getMessage());
        }
        return response;
    }

    @PostMapping("/login")
    public LoginResponse login(@RequestBody User user) {
        try {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?";
            List<Map<String, Object>> res = jdbcTemplate.queryForList(sql, user.getUsername(), user.getPassword(), user.getRole());
            if (res.isEmpty()) return new LoginResponse("error", "Invalid credentials.", null, null);

            String userId = (String) res.get(0).get("user_id");
            String role = user.getRole().toUpperCase();
            LoginResponse response = new LoginResponse("success", "Login successful", role, userId);

            if ("SUPPLIER".equals(role)) {
                response.data = jdbcTemplate.queryForList("SELECT request_id, title FROM procurement_requests WHERE status = 'Open'");
            } else if ("ADMIN".equals(role)) {
                response.data = jdbcTemplate.queryForList("SELECT request_id, title, status FROM procurement_requests");
            } else if ("BUYER".equals(role)) {
                response.data = jdbcTemplate.queryForList("SELECT request_id, title, status FROM procurement_requests WHERE buyer_id = ?", userId);
            }

            return response;
        } catch (Exception e) {
            return new LoginResponse("error", "Login error: " + e.getMessage(), null, null);
        }
    }

    // Add other endpoints here:
    // /procurement (POST)
    // /bid (POST)
    // /open (POST)
    // /approve (POST)
    // /results (GET)
    // /orders (GET)
}
