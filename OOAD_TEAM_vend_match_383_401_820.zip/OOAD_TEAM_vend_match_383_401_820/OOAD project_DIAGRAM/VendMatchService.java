package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class VendMatchService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void createDefaultAdmin() {
        try {
            Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM users WHERE username = ?", Integer.class, "sam");
            if (count == 0) {
                jdbcTemplate.update("INSERT INTO users (user_id, username, password, role) VALUES (?, ?, ?, ?)",
                        "SAM1", "sam", "1718", "ADMIN");
                System.out.println("✅ Default admin created: sam / 1718");
            }
        } catch (Exception e) {
            System.err.println("❌ Admin creation error: " + e.getMessage());
        }
    }

    public void checkAndCreateResultAndOrder(String bidId) {
        try {
            Map<String, Object> bid = jdbcTemplate.queryForMap("SELECT * FROM bids WHERE bid_id = ?", bidId);
            if ("Yes".equals(bid.get("admin_approval")) && "Yes".equals(bid.get("buyer_approval"))) {
                String requestId = (String) bid.get("request_id");
                Double amount = (Double) bid.get("amount");
                String supplierId = (String) bid.get("supplier_id");
                String buyerId = jdbcTemplate.queryForObject("SELECT buyer_id FROM procurement_requests WHERE request_id = ?", String.class, requestId);

                jdbcTemplate.update("INSERT INTO results (request_id, supplier_id, amount) VALUES (?, ?, ?)", requestId, supplierId, amount);

                String orderId = "order" + System.currentTimeMillis();
                jdbcTemplate.update("INSERT INTO orders (order_id, request_id, supplier_id, buyer_id) VALUES (?, ?, ?, ?)",
                        orderId, requestId, supplierId, buyerId);
            }
        } catch (Exception e) {
            System.err.println("❌ Error creating result/order: " + e.getMessage());
        }
    }
}
