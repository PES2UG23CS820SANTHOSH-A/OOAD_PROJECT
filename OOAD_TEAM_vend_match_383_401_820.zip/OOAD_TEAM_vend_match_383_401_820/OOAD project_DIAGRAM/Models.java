package com.example.demo;

import java.util.*;

public class Models {

    public static class User {
        private String username, password, role;
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
    }

    public static class ProcurementRequest {
        private String title, items, itemsQuantity, buyerId;
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getItems() { return items; }
        public void setItems(String items) { this.items = items; }
        public String getItemsQuantity() { return itemsQuantity; }
        public void setItemsQuantity(String itemsQuantity) { this.itemsQuantity = itemsQuantity; }
        public String getBuyerId() { return buyerId; }
        public void setBuyerId(String buyerId) { this.buyerId = buyerId; }
    }

    public static class Bid {
        private double amount;
        private String supplierId, requestId;
        public double getAmount() { return amount; }
        public void setAmount(double amount) { this.amount = amount; }
        public String getSupplierId() { return supplierId; }
        public void setSupplierId(String supplierId) { this.supplierId = supplierId; }
        public String getRequestId() { return requestId; }
        public void setRequestId(String requestId) { this.requestId = requestId; }
    }

    public static class LoginResponse {
        public String status, message, role, userId;
        public List<Map<String, Object>> data = new ArrayList<>();
        public LoginResponse(String status, String message, String role, String userId) {
            this.status = status;
            this.message = message;
            this.role = role;
            this.userId = userId;
        }
    }
}
